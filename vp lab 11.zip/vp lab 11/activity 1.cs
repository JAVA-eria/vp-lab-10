﻿using System.Windows;
using System.Windows.Media.Imaging;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            BitmapImage bitmap = new BitmapImage(new Uri("C:\Users\233573\source\repos\WpfApp3\WpfApp3\image\Starry-Night-canvas-Vincent-van-Gogh-New-1889.webp"));
            BitmapImage bitmap = new BitmapImage(new Uri("C:\Users\233573\source\repos\WpfApp3\WpfApp3\image\Bedroom-oil-canvas-Vincent-van-Gogh-Art-1889.webp"));
            myImage.Source = bitmap; // Assuming you have named your Image control as "myImage"
        }
    }
}