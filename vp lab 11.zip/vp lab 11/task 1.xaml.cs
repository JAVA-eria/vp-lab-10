﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace BringBackPocoyo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Create a new Border control
            Border border = new Border();

            // Create a new StackPanel control
            StackPanel stackPanel = new StackPanel();
            stackPanel.Orientation = Orientation.Horizontal;

            // Add images to the StackPanel
            Image image1 = new Image();
            image1.Source = new BitmapImage(new Uri("C:\Users\233573\source\repos\WpfApp7\WpfApp7\images\Bedroom-oil-canvas-Vincent-van-Gogh-Art-1889.webp"));
            stackPanel.Children.Add(image1);

            Image image2 = new Image();
            image2.Source = new BitmapImage(new Uri("C:\Users\233573\source\repos\WpfApp7\WpfApp7\images\Starry-Night-canvas-Vincent-van-Gogh-New-1889.webp"));
            stackPanel.Children.Add(image2);

            Image image3 = new Image();
            image3.Source = new BitmapImage(new Uri("C:\Users\233573\source\repos\WpfApp7\WpfApp7\images\Van-Gogh-Irises-1889-St-Paul-de-Mausole-Asylum-1024-x-695.webp"));
            stackPanel.Children.Add(image3);

            // Add the StackPanel to the Border
            border.Child = stackPanel;

            // Add the Border to the Window
            Content = border;
        }
    }
}