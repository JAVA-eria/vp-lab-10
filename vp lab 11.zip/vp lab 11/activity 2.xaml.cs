﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WPFCheckBoxControl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void HandleCheck(object sender, RoutedEventArgs e)
        {
            // Handle check event for both check boxes
            CheckBox checkBox = (CheckBox)sender;
            if (checkBox.IsChecked == true)
            {
                // Do something when the check box is checked
                MessageBox.Show("Checked");
            }
        }

        private void HandleUnchecked(object sender, RoutedEventArgs e)
        {
            // Handle uncheck event for both check boxes
            CheckBox checkBox = (CheckBox)sender;
            if (checkBox.IsChecked == false)
            {
                // Do something when the check box is unchecked
                MessageBox.Show("Unchecked");
            }
        }

        private void HandleThirdState(object sender, RoutedEventArgs e)
        {
            // Handle third state event for checkBox2
            CheckBox checkBox = (CheckBox)sender;
            if (checkBox.IsThreeState == true && checkBox.IsChecked == null)
            {
                // Do something when the check box is in the third state
                MessageBox.Show("Third State");
            }
        }
    }
}